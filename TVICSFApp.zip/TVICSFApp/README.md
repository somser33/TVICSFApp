# TV ICSF — Android App

A full-featured Android WebView wrapper for **TV ICSF**  
`https://islamic-cybersecurity-force.top/tv-icsf/index.php`

---

## Features

| Feature | Details |
|---|---|
| WebView streaming | Hardware-accelerated, optimised for live TV |
| JavaScript | Enabled |
| DOM Storage | Enabled |
| Fullscreen video | Immersive-sticky fullscreen with back-to-normal |
| File uploads | Camera + gallery picker |
| Progress bar | Thin green indicator at the top |
| No-internet screen | Friendly error with retry button |
| Back navigation | Back button navigates WebView history |
| Screen awake | `FLAG_KEEP_SCREEN_ON` keeps display on |
| Cookies | Third-party cookies enabled |
| Mixed content | Allowed for streaming compatibility |
| Material Design | Dark theme with green accent |

---

## Project Structure

```
TVICSFApp/
├── app/
│   ├── src/main/
│   │   ├── java/com/tvicsf/app/
│   │   │   └── MainActivity.java          ← Main activity with full WebView logic
│   │   ├── res/
│   │   │   ├── layout/activity_main.xml   ← UI layout
│   │   │   ├── values/
│   │   │   │   ├── strings.xml
│   │   │   │   ├── colors.xml
│   │   │   │   └── themes.xml
│   │   │   ├── xml/
│   │   │   │   ├── network_security_config.xml
│   │   │   │   └── file_provider_paths.xml
│   │   │   └── mipmap-*/                  ← Launcher icons (all densities)
│   │   └── AndroidManifest.xml
│   ├── build.gradle
│   └── proguard-rules.pro
├── build.gradle
├── settings.gradle
├── gradle.properties
└── gradle/wrapper/gradle-wrapper.properties
```

---

## How to Build

### Requirements
- **Android Studio** Hedgehog (2023.1.1) or newer  
- **JDK 17** (bundled with Android Studio)  
- **Android SDK** with API level 21–34

### Steps

1. **Clone / unzip** this project folder.

2. **Set your SDK path** – copy `local.properties.template` to `local.properties` and update `sdk.dir`:
   ```
   sdk.dir=/Users/YOUR_NAME/Library/Android/sdk
   ```

3. **Open in Android Studio** → *File → Open* → select the `TVICSFApp` folder.

4. Let Gradle sync complete.

5. Click **▶ Run** (or `Shift+F10`) to build and deploy to a device / emulator.

### Build APK from command line
```bash
chmod +x gradlew
./gradlew assembleDebug
# APK output: app/build/outputs/apk/debug/app-debug.apk
```

For a signed release APK:
```bash
./gradlew assembleRelease
```

---

## Package Info

| Key | Value |
|---|---|
| Package name | `com.tvicsf.app` |
| Min SDK | 21 (Android 5.0 Lollipop) |
| Target SDK | 34 (Android 14) |
| Version | 1.0.0 (code 1) |
| Language | Java |

---

## Permissions Used

| Permission | Reason |
|---|---|
| `INTERNET` | Load website |
| `ACCESS_NETWORK_STATE` | Detect offline state |
| `WAKE_LOCK` | Keep screen on while watching |
| `READ_EXTERNAL_STORAGE` | File upload (Android ≤ 12) |
| `READ_MEDIA_VIDEO/IMAGES` | File upload (Android 13+) |
| `CAMERA` | Camera upload from website |
| `RECORD_AUDIO` | Mic access if website requests |

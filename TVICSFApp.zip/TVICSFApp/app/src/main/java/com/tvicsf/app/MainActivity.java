package com.tvicsf.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    // ─── Constants ─────────────────────────────────────────────────────────────
    private static final String WEBSITE_URL = "https://islamic-cybersecurity-force.top/tv-icsf/index.php";
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;
    private static final int PERMISSION_REQUEST_CODE   = 1002;
    private static final int CAMERA_REQUEST_CODE       = 1003;

    // ─── Views ──────────────────────────────────────────────────────────────────
    private WebView          webView;
    private ProgressBar      progressBar;
    private LinearLayout     errorLayout;
    private TextView         errorMessage;
    private Button           retryButton;
    private FrameLayout      fullscreenContainer;
    private View             customView;

    // ─── State ──────────────────────────────────────────────────────────────────
    private WebChromeClient.CustomViewCallback customViewCallback;
    private ValueCallback<Uri[]>               filePathCallback;
    private Uri                                cameraImageUri;
    private boolean                            isFullscreen = false;
    private boolean                            isPageLoaded = false;

    // ─────────────────────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Keep screen on during streaming
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setContentView(R.layout.activity_main);

        initViews();
        setupWebView();
        loadWebsite();
    }

    // ─── View Initialisation ──────────────────────────────────────────────────

    private void initViews() {
        webView             = findViewById(R.id.webView);
        progressBar         = findViewById(R.id.progressBar);
        errorLayout         = findViewById(R.id.errorLayout);
        errorMessage        = findViewById(R.id.errorMessage);
        retryButton         = findViewById(R.id.retryButton);
        fullscreenContainer = findViewById(R.id.fullscreenContainer);

        retryButton.setOnClickListener(v -> loadWebsite());
    }

    // ─── WebView Setup ────────────────────────────────────────────────────────

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void setupWebView() {
        WebSettings settings = webView.getSettings();

        // JavaScript & DOM Storage
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);

        // Streaming optimisations
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setSupportZoom(false);

        // Caching
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setAppCacheEnabled(true);

        // Mixed content (required for some streaming sites)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        // File access
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        // User-Agent: keep default Android UA for best compatibility
        String defaultUA = settings.getUserAgentString();
        settings.setUserAgentString(defaultUA);

        // Hardware acceleration is set at application level; ensure layer type
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        // Cookies
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.setAcceptThirdPartyCookies(webView, true);
        }

        webView.setWebViewClient(new TvWebViewClient());
        webView.setWebChromeClient(new TvWebChromeClient());
        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
    }

    // ─── Load ─────────────────────────────────────────────────────────────────

    private void loadWebsite() {
        if (isNetworkAvailable()) {
            hideError();
            webView.setVisibility(View.VISIBLE);
            webView.loadUrl(WEBSITE_URL);
        } else {
            showError(getString(R.string.error_no_internet));
        }
    }

    // ─── Network check ───────────────────────────────────────────────────────

    private boolean isNetworkAvailable() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            NetworkCapabilities caps =
                    cm.getNetworkCapabilities(cm.getActiveNetwork());
            return caps != null &&
                    (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                     || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                     || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
        } else {
            NetworkInfo ni = cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected();
        }
    }

    // ─── Error UI ────────────────────────────────────────────────────────────

    private void showError(String message) {
        webView.setVisibility(View.GONE);
        progressBar.setVisibility(View.GONE);
        errorLayout.setVisibility(View.VISIBLE);
        errorMessage.setText(message);
    }

    private void hideError() {
        errorLayout.setVisibility(View.GONE);
    }

    // ─── WebViewClient ───────────────────────────────────────────────────────

    private class TvWebViewClient extends WebViewClient {

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setProgress(0);
            isPageLoaded = false;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            progressBar.setVisibility(View.GONE);
            isPageLoaded = true;
            CookieManager.getInstance().flush();
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request,
                                    WebResourceError error) {
            super.onReceivedError(view, request, error);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                // Only show error for main frame failures
                if (request.isForMainFrame()) {
                    if (!isNetworkAvailable()) {
                        showError(getString(R.string.error_no_internet));
                    } else {
                        showError(getString(R.string.error_page_load));
                    }
                }
            }
        }

        @SuppressWarnings("deprecation")
        @Override
        public void onReceivedError(WebView view, int errorCode,
                                    String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                if (!isNetworkAvailable()) {
                    showError(getString(R.string.error_no_internet));
                } else {
                    showError(getString(R.string.error_page_load));
                }
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                String url = request.getUrl().toString();
                return handleUrl(view, url);
            }
            return false;
        }

        @SuppressWarnings("deprecation")
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handleUrl(view, url);
        }

        private boolean handleUrl(WebView view, String url) {
            // Keep all links inside the WebView
            if (url.startsWith("http://") || url.startsWith("https://")) {
                view.loadUrl(url);
                return true;
            }
            // Handle tel: / mailto: etc. with intents
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(MainActivity.this,
                        getString(R.string.error_open_link), Toast.LENGTH_SHORT).show();
            }
            return true;
        }
    }

    // ─── WebChromeClient ─────────────────────────────────────────────────────

    private class TvWebChromeClient extends WebChromeClient {

        // Progress
        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            progressBar.setProgress(newProgress);
            if (newProgress == 100) {
                new Handler(Looper.getMainLooper()).postDelayed(
                        () -> progressBar.setVisibility(View.GONE), 300);
            }
        }

        // ── Fullscreen video ──────────────────────────────────────────────────

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (customView != null) {
                callback.onCustomViewHidden();
                return;
            }
            customView = view;
            customViewCallback = callback;

            fullscreenContainer.addView(customView);
            fullscreenContainer.setVisibility(View.VISIBLE);
            webView.setVisibility(View.GONE);

            hideSystemUI();
            isFullscreen = true;
        }

        @Override
        public void onHideCustomView() {
            if (customView == null) return;

            fullscreenContainer.removeView(customView);
            fullscreenContainer.setVisibility(View.GONE);
            customView = null;

            webView.setVisibility(View.VISIBLE);
            showSystemUI();
            isFullscreen = false;

            if (customViewCallback != null) {
                customViewCallback.onCustomViewHidden();
                customViewCallback = null;
            }
        }

        // ── File Chooser ──────────────────────────────────────────────────────

        @Override
        public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                          FileChooserParams fileChooserParams) {
            if (MainActivity.this.filePathCallback != null) {
                MainActivity.this.filePathCallback.onReceiveValue(null);
            }
            MainActivity.this.filePathCallback = filePathCallback;

            requestFilePermissionsAndOpen(fileChooserParams);
            return true;
        }

        // ── JS Dialogs ────────────────────────────────────────────────────────

        @Override
        public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
            result.confirm();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
            result.confirm();
            return true;
        }

        // ── Permissions (camera, mic) ─────────────────────────────────────────

        @Override
        public void onPermissionRequest(final PermissionRequest request) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                runOnUiThread(() -> {
                    String[] perms = new String[]{
                            Manifest.permission.CAMERA,
                            Manifest.permission.RECORD_AUDIO
                    };
                    boolean allGranted = true;
                    for (String p : perms) {
                        if (ContextCompat.checkSelfPermission(MainActivity.this, p)
                                != PackageManager.PERMISSION_GRANTED) {
                            allGranted = false;
                            break;
                        }
                    }
                    if (allGranted) {
                        request.grant(request.getResources());
                    } else {
                        ActivityCompat.requestPermissions(MainActivity.this, perms,
                                PERMISSION_REQUEST_CODE);
                    }
                });
            }
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin,
                                                        GeolocationPermissions.Callback callback) {
            callback.invoke(origin, true, false);
        }

        @Override
        public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
            // Suppress console spam in release; keep for debug
            return true;
        }
    }

    // ─── File chooser helpers ────────────────────────────────────────────────

    private void requestFilePermissionsAndOpen(WebChromeClient.FileChooserParams params) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            openFileChooser(params);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String perm = Manifest.permission.READ_EXTERNAL_STORAGE;
            if (ContextCompat.checkSelfPermission(this, perm)
                    == PackageManager.PERMISSION_GRANTED) {
                openFileChooser(params);
            } else {
                ActivityCompat.requestPermissions(this, new String[]{perm},
                        PERMISSION_REQUEST_CODE);
            }
        } else {
            openFileChooser(params);
        }
    }

    private void openFileChooser(WebChromeClient.FileChooserParams params) {
        Intent chooserIntent = null;

        // Camera intent
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File photoFile = null;
        try {
            photoFile = createImageFile();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                cameraImageUri = FileProvider.getUriForFile(this,
                        getApplicationContext().getPackageName() + ".provider", photoFile);
            } else {
                cameraImageUri = Uri.fromFile(photoFile);
            }
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, cameraImageUri);
        } catch (IOException | IllegalArgumentException e) {
            cameraImageUri = null;
        }

        // File picker intent
        Intent contentIntent = new Intent(Intent.ACTION_GET_CONTENT);
        contentIntent.addCategory(Intent.CATEGORY_OPENABLE);
        contentIntent.setType("*/*");

        if (cameraImageUri != null) {
            chooserIntent = Intent.createChooser(contentIntent,
                    getString(R.string.choose_file));
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS,
                    new Intent[]{cameraIntent});
        } else {
            chooserIntent = Intent.createChooser(contentIntent,
                    getString(R.string.choose_file));
        }

        try {
            startActivityForResult(chooserIntent, FILE_CHOOSER_REQUEST_CODE);
        } catch (Exception e) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                .format(new Date());
        String imageFileName = "TVICSF_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        return File.createTempFile(imageFileName, ".jpg", storageDir);
    }

    // ─── Activity Results ────────────────────────────────────────────────────

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) return;

            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK) {
                if (data != null && data.getData() != null) {
                    results = new Uri[]{data.getData()};
                } else if (cameraImageUri != null) {
                    results = new Uri[]{cameraImageUri};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    // ─── Permission results ──────────────────────────────────────────────────

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                            @NonNull String[] permissions,
                                            @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            // Silently handled; WebChromeClient.onPermissionRequest will re-fire
        }
    }

    // ─── System UI helpers (fullscreen) ─────────────────────────────────────

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    private void showSystemUI() {
        View decorView = getWindow().getDecorView();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ─── Back button ────────────────────────────────────────────────────────

    @Override
    public void onBackPressed() {
        if (isFullscreen) {
            // Exit fullscreen first
            if (customViewCallback != null) {
                customViewCallback.onCustomViewHidden();
            }
            return;
        }
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    // ─── Lifecycle ───────────────────────────────────────────────────────────

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
        webView.resumeTimers();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
        webView.pauseTimers();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.clearHistory();
            webView.removeAllViews();
            webView.destroy();
        }
        super.onDestroy();
    }

    // ─── Key Events ─────────────────────────────────────────────────────────

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}

# TV ICSF ProGuard Rules

# Keep WebView JavaScript interface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep WebView related classes
-keep class android.webkit.** { *; }

# Keep our app classes
-keep class com.tvicsf.app.** { *; }

# Material components
-keep class com.google.android.material.** { *; }

# AndroidX
-keep class androidx.** { *; }

# FileProvider
-keep class androidx.core.content.FileProvider { *; }

# Suppress warnings for known safe omissions
-dontwarn android.webkit.**
-dontwarn com.google.android.material.**
